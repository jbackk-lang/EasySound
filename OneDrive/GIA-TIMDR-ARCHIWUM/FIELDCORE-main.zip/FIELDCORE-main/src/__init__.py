# Inicjalizacja modułu FIELDCORE
