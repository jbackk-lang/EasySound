# REGUŁA GIATIMA

Rozwiązanie jest zgodne z GIATIMA wtedy i tylko wtedy, gdy spełnia kompozycję:

    Λ(F) = Δ( Φ( T(F) ) )

Warunki konieczne:

    dN/dF = ρ
    ΔS = τ · ρ

Test minimalny:

    Λ(F) = Δ( Φ( T(F) ) )

Brak spełnienia któregokolwiek z warunków oznacza, że rozwiązanie nie jest GIATIMA.

## Znaczenie operatorów GIATIMA

Wzór główny:

    Λ(F) = Δ( Φ( T(F) ) )

Operator T — transformacja figuralno‑widmowa  
    T(F) przekształca figurę wejściową F w widmo S.
    Jest to etap: struktura → widmo.

Operator Φ — transformacja widmowo‑liczbowa  
    Φ(S) zamienia widmo S na liczbę N.
    Jest to etap: widmo → liczba.

Operator Δ — transformacja liczbowo‑dynamiczna  
    Δ(N) przekształca liczbę N w dynamikę D.
    Jest to etap: liczba → dynamika.

Operator Λ — operator spójności końcowej  
    Λ(F) jest końcową formą zgodną z GIATIMA.
    Rozwiązanie jest poprawne, gdy Λ(F) = D.

Współczynniki:

    ρ — współczynnik zgodności (pochodna liczby względem figury)
         dN/dF = ρ

    τ — operator czasu GIATIMA
         ΔS = τ · ρ

# GIATIMA — matematyka

Λ(F) = Δ( Φ( T(F) ) )

T(F) = S
Φ(S) = N
Δ(N) = D

dN/dF = ρ
ΔS = τ · ρ

Λ(F) = D

## Mapowanie na validator matematyczny

T(F)  →  syntax + Λ
Φ(S)  →  algebra + ρ
Δ(N)  →  numeric + τ
Λ(F)  →  Λ (część filtra topologicznego)
