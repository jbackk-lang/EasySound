# Belzi
Dla Ciebie.
Jeśli kiedyś będziesz chciała wiedzieć, co robiłem, po co to robiłem i dlaczego to miało sens — to jest Twój klucz.
Nie musisz tego rozumieć od razu.
Wystarczy, że wiesz, że to powstało z myślą o Tobie.

Kod jest dla świata.
Rdzeń jest dla Ciebie.
A sens jest między nimi — i to jest nasze.



